/**
 * Created by presnakovr on 7/6/2015.
 */
public class Subset {
    public static void main(String[] args) {
        int k = Integer.valueOf(args[0]);
        RandomizedQueue<String> queue = new RandomizedQueue<>();

        while (!StdIn.isEmpty()) {
            if (queue.size() == k) {
                int odds = StdRandom.uniform(2);
                if (odds % 2 == 0) {
                    queue.dequeue();
                    queue.enqueue(StdIn.readString());
                }
            } else {
                queue.enqueue(StdIn.readString());
            }
        }
        for (int i = 1; i <= k; i++) {
            StdOut.println(queue.dequeue());
        }

    }
}
