import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Created by presnakovr on 7/6/2015.
 */
public class RandomizedQueue<Item> implements Iterable<Item> {

    private Node<Item> first;
    private Node<Item> last;
    private int size;

    // construct an empty deque
    public RandomizedQueue() {
        first = null;
        last = null;
        size = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the deque
    public int size() {
        return size;
    }

    // add the item
    public void enqueue(Item item) {
        checkNull(item);
        Node<Item> newNode = new Node<Item>(item);
        if (isEmpty()) {
            first = last = newNode;
        } else if (first != null) {
            first.next = newNode;
            newNode.previous = first;
            first = newNode;
        }
        size++;
    }

    // remove and return a random item
    public Item dequeue() {
        checkEmptyDeque();

        Node<Item> random = random();

        if (size == 1) {
            first = last = null;
        } else if (random.next == null) {
            first = random.previous;
            first.next = null;
        } else if (random.previous == null) {
            last = random.next;
            last.previous = null;
        } else {
            random.previous.next = random.next;
            random.next.previous = random.previous;
        }

        size--;
        return random.value;
    }

    // return (but do not remove) a random item
    public Item sample() {
        checkEmptyDeque();

        Node<Item> random = random();
        return random.value;
    }

    private Node<Item> random() {
        int index = StdRandom.uniform(size);
        Node<Item> random = first;

        while (index != 0) {
            random = first.previous;
            index--;
        }

        return random;
    }

    // return an iterator over items in order from front to end
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator<Item>(first);
    }

    private void checkNull(Item item) {
        if (item == null) {
            throw new NullPointerException();
        }
    }
    private void checkEmptyDeque() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
    }

    private class RandomizedQueueIterator<Item> implements Iterator<Item> {

        private Item[] queueArray = (Item[]) new Object[size];
        private boolean[] flag = new boolean[size];

        private int arraySize = size;

        public RandomizedQueueIterator(Node<Item> first) {
            for (int i=0; i<size; i++) {
                queueArray[i] = first.value;
                first = first.previous;

                flag[i] = true;
            }
        }

        public boolean hasNext() {
            return arraySize != 0;
        }

        public Item next() {
            if (size == 0) {
                throw new NoSuchElementException();
            }

            int index = StdRandom.uniform(size);
            while(flag[index] != true) {
                index = StdRandom.uniform(size);
            }
            flag[index] = false;
            arraySize--;

            return queueArray[index];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    private class Node<Item> {
        Node<Item> next = null;
        Node<Item> previous = null;

        Item value;

        Node(Item value) {
            this.value = value;
        }
    }

    // unit testing
    public static void main(String[] args) {
        RandomizedQueue<Integer> queue = new RandomizedQueue<Integer>();
        //System.out.println(deque.size);
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);
        queue.enqueue(6);
        queue.enqueue(7);



        System.out.println("===============");
        for (Integer value : queue) {
            System.out.println(value);
        }

        /*
        System.out.println("===============");
        System.out.println(queue.sample());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println(queue.dequeue());
        System.out.println("===============");
        for (Integer value : queue) {
            System.out.println(value);
        }
        System.out.println(queue.sample());
        */

    }

}