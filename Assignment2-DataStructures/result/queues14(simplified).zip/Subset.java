/**
 * Created by presnakovr on 7/6/2015.
 */
public class Subset {
    public static void main(String[] args) {
        int k = Integer.valueOf(args[0]);
        RandomizedQueue<String> queue = new RandomizedQueue<>();

        while (!StdIn.isEmpty()) {
            queue.enqueue(StdIn.readString());

            if (queue.size() > k) {
                queue.dequeue();
            }
        }
        for (int i = 1; i <= k; i++) {
            StdOut.println(queue.dequeue());
        }

    }
}
