import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Created by presnakovr on 7/6/2015.
 */
public class RandomizedQueue<Item> implements Iterable<Item> {

    private int size;
    private int max;
    private Item[] arr;
    private int pointer;

    // construct an empty deque
    public RandomizedQueue() {
        size = 0;
        max = 2;
        arr = (Item[]) new Object[max];

        pointer = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the deque
    public int size() {
        return size;
    }

    // add the item
    public void enqueue(Item item) {
        checkNull(item);

        if (pointer == max) {
            max = max * 2;
            resizeArray();
        }
        arr[pointer] = item;
        pointer++;
        size++;
    }

    // remove and return a random item
    public Item dequeue() {
        checkEmptyDeque();

        int ind = StdRandom.uniform(pointer);

        //looking for the nearest not null element
        while (arr[ind] == null) {
            ind = StdRandom.uniform(pointer);
        }
        Item value = arr[ind];
        arr[ind] = null;
        size--;

        if (size > 0 && size == max / 4) {
            max = max / 2;
            resizeArray();
        }
        return value;
    }

    private void resizeArray() {
        Item[] backup = arr;
        arr = (Item[]) new Object[max];

        int j = 0;
        for (int i = 0; i < size; i++) {
            while (backup[j] == null) {
                j++;
            }

            arr[i] = backup[j];
            j++;
        }

        pointer = size;
    }

    // return (but do not remove) a random item
    public Item sample() {
        checkEmptyDeque();

        int ind = StdRandom.uniform(pointer);
        while (arr[ind] == null) {
            ind = StdRandom.uniform(pointer);
        }
        return arr[ind];
    }

    // return an iterator over items in order from front to end
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator<Item>();
    }

    private void checkNull(Item item) {
        if (item == null) {
            throw new NullPointerException();
        }
    }
    private void checkEmptyDeque() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
    }

    private class RandomizedQueueIterator<Item> implements Iterator<Item> {

        private Item[] queueArray;

        private int arrayInd = size;

        public RandomizedQueueIterator() {
            queueArray = (Item[]) new Object[size];
            int j = 0;
            for (int i = 0; i < size; i++) {
                while (arr[j] == null) {
                    j++;
                }
                queueArray[i] = (Item) arr[j];
                j++;
            }
            StdRandom.shuffle(queueArray);
        }

        public boolean hasNext() {
            return arrayInd > 0;
        }

        public Item next() {
            arrayInd--;

            if (arrayInd < 0) {
                throw new NoSuchElementException();
            }
            return queueArray[arrayInd];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing
    public static void main(String[] args) {
   }

}