/**
 * Created by presnakovr on 7/6/2015.
 */
public class Subset {
    public static void main(String[] args) {
        StdOut.println("Holy cow!");
    }
}
