/**
 * Created by presnakovr on 7/6/2015.
 */
public class Subset {
    public static void main(String[] args) {
        int k = StdIn.readInt();
        int n = 0;
        RandomizedQueue<String> queue = new RandomizedQueue<>();

        while (!StdIn.isEmpty()) {
            queue.enqueue(StdIn.readString());
        }
        for (int i = 1; i <= k; i++) {
            StdOut.println(queue.dequeue());
        }

    }
}
