import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Created by presnakovr on 7/6/2015.
 */
public class RandomizedQueue<Item> implements Iterable<Item> {

    private int size;
    private int max;
    private Item[] arr;
    private int pointer;

    // construct an empty deque
    public RandomizedQueue() {
        size = 0;
        max = 2;
        arr = (Item[]) new Object[max];

        pointer = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the deque
    public int size() {
        return size;
    }

    // add the item
    public void enqueue(Item item) {
        checkNull(item);

        if (pointer == max) {
            max = max * 2;
            resizeArray();
        }
        arr[pointer] = item;
        pointer++;
        size++;
        //System.out.println("added item=" + item + "; size=" + size);
    }

    private void resizeArray() {
        Item[] backup = arr;
        arr = (Item[]) new Object[max];

        int j = 0;
        for (int i = 0; i < size; i++) {
//            try {
                while (backup[j] == null) {
                    j++;
                }
//            } catch (ArrayIndexOutOfBoundsException ex) {
//                int a = 5;
//            }

            arr[i] = backup[j];
            j++;
        }

        pointer = size;
    }

    // remove and return a random item
    public Item dequeue() {
        checkEmptyDeque();

        int ind = StdRandom.uniform(size);

        //looking for the nearest not null element
        while (arr[ind] == null) {
            ind++;
            if (ind == max) {
                ind = 0;
            }
        }
        Item value = arr[ind];
        arr[ind] = null;
        size--;

//        while (ind < (size - 1)) {
//            arr[ind] = arr[ind + 1];
//            ind++;
//        }
//        arr[size - 1] = null;
//        size--;

        if (size > 0 && size == max / 4) {
            max = max / 2;
            resizeArray();
        }
        //System.out.println("deleted item=" + value + "; size=" + size);
        return value;
    }

    // return (but do not remove) a random item
    public Item sample() {
        checkEmptyDeque();

        int ind = StdRandom.uniform(size);
        return arr[ind];
    }

    // return an iterator over items in order from front to end
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator<Item>();
    }

    private void checkNull(Item item) {
        if (item == null) {
            throw new NullPointerException();
        }
    }
    private void checkEmptyDeque() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
    }

    private class RandomizedQueueIterator<Item> implements Iterator<Item> {

        private Item[] queueArray;

        private int arrayInd = size;

        public RandomizedQueueIterator() {
            queueArray = (Item[]) new Object[size];
            for (int i = 0; i < size; i++) {
                queueArray[i] = (Item) arr[i];
            }
            StdRandom.shuffle(queueArray);
        }

        public boolean hasNext() {
            return arrayInd > 0;
        }

        public Item next() {
            arrayInd--;

            if (arrayInd < 0) {
                throw new NoSuchElementException();
            }
            return queueArray[arrayInd];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing
    public static void main(String[] args) {
//        RandomizedQueue<Integer> queue = new RandomizedQueue<Integer>();
//        //System.out.println(deque.size);
//        queue.enqueue(1);
//        queue.enqueue(2);
//        queue.enqueue(3);
//        queue.enqueue(4);
//        queue.enqueue(5);
//        queue.enqueue(6);
//        queue.enqueue(7);
//
//        System.out.println("===============");
//        for (Integer value : queue) {
//            System.out.println(value);
//        }
//        System.out.println("===============");
//        System.out.println(queue.sample());
//        System.out.println(queue.sample());
//        System.out.println(queue.sample());
//        System.out.println("===============");
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        queue.enqueue(11);
//        queue.enqueue(22);
//        queue.enqueue(33);
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        System.out.println(queue.dequeue());
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//        queue.enqueue(6);
//        queue.enqueue(7);
//
////        /*
////        System.out.println("===============");
////        System.out.println(queue.sample());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println(queue.dequeue());
////        System.out.println("===============");
////        for (Integer value : queue) {
////            System.out.println(value);
////        }
////        System.out.println(queue.sample());
////        */

    }

}