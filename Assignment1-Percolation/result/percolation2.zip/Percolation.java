/**
 * Created by presnakovr on 7/2/2015.
 */
public class Percolation {

    private int n;
    private WeightedQuickUnionUF uf;

    private int[] area;

    // create N-by-N grid, with all sites blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw  new IllegalArgumentException();
        }

        this.n = n;

        uf = new WeightedQuickUnionUF(n * n);

    area = new int[n * n];
    for (int i = 0; i < n*n; i++) {
        area[i] = 1;
    }
}

    // open site (row i, column j) if it is not open already
    public void open(int i, int j) {
        if (i < 1 || i > n || j < 1 || j > n) {
            throw new IndexOutOfBoundsException();
        }

        area[getIndex(i, j)] = 0;
        checAndConnectkNeighbours(i, j, i, j - 1);
        checAndConnectkNeighbours(i, j, i, j + 1);
        checAndConnectkNeighbours(i, j, i - 1, j);
        checAndConnectkNeighbours(i, j, i + 1, j);
    }

    private void checAndConnectkNeighbours(int i, int j, int ii, int jj) {
        if (ii >= 1 && ii <= n && jj >= 1 && jj <= n && isOpen(ii, jj)) {
            if (!uf.connected(getIndex(i, j), getIndex(ii, jj))) {
                uf.union(getIndex(i, j), getIndex(ii, jj));
            }
        }
    }

    // is site (row i, column j) open?
    public boolean isOpen(int i, int j) {
        if (i < 1 || i > n || j < 1 || j > n) {
            throw new IndexOutOfBoundsException();
        }

        return area[getIndex(i, j)] == 0;
    }

    // is site (row i, column j) full?
    public boolean isFull(int i, int j) {
        if (i < 1 || i > n || j < 1 || j > n) {
            throw new IndexOutOfBoundsException();
        }

        if (!isOpen(i, j)) {
            return false;
        }

        boolean result = false;

        for (int col = 1; col <= n; col++) {
            result = uf.connected(getIndex(i, j), getIndex(1, col));
            if (result) {
                break;
            }
        }

        return result;
    }

    // does the system percolate?
    public boolean percolates()  {
        boolean result = false;

        for (int col = 1; col <= n; col++) {
            result = isFull(n, col);
            if (result) {
                break;
            }
        }
        return result;
    }

    private int getIndex(int i, int j) {
        return n * (i - 1) + (j  -1);
    }

    // test client (optional)
    public static void main(String[] args) {
//        int N = StdIn.readInt();
//        Percolation perc = new Percolation(N);
//        while (!StdIn.isEmpty()) {
//            int p = StdIn.readInt();
//            int q = StdIn.readInt();
//
//            perc.open(p, q);
//            StdOut.println(perc.isFull(p, q));
//            StdOut.println(perc.percolates());
//
//            if (p == 5 && q == 4) {
//                break;
//            }
//        }
//
//        StdOut.println(perc.isFull(1, 1));
    }
}
